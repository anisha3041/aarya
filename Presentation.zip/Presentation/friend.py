class Friend:
    def __init__(self,name,dob,mobile,email,pincode):
        self.name=name
        self.dob=dob
        self.mobile=mobile
        self.email=email
        self.pincode=pincode
    def display_friend(self):
        print(f"Name:{self.name}\nDOB:{self.dob}\nMobile:{self.mobile}\nEmail{self.email}\nPincode{self.pincode}")