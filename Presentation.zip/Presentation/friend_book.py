import mysql.connector
from mysql.connector import Error
from friend import Friend

class FriendBook:
    def __init__(self):
        self.connection=self.create_connection()  

    def create_connection(self):
            try:
                connection=mysql.connector.connect(
                    host='localhost',
                    database='friend_book',
                    user='root',
                    password='ani_20@4#sql'
                )
                if connection.is_connected():
                    return connection
            except Error as e:
                print(f"Error:{e}")
                return None
            
    def add_friend(self,Friend):
            cursor=self.connection.cursor()
            query='INSERT INTO  friend (name,dob,mobile,email,pincode) (%s,%s,%s,%s,%s)'
            values=(Friend.name,Friend.dob,Friend.mobile,Friend.email,Friend.pincode)
            cursor.execute(query,values)
            self.connection.commit()
            print("Friend added sucessfully!")

        #display all friends
    def display_all_friend(self):
            cursor=self.connection.cursor(dictionary=True)
            query="Select * FROM friend"
            cursor.execute(query)
            results=cursor.fetchall()
            for row in results:
                friend=Friend(row['name'],row['dob'],row['mobile'],row['email'],row['pincode'])
                friend.display_friend()
                print("-----------------")

        #update friend function
    def update_friend(self,name,new_name=None,new_dob=None,new_mobile=None,new_email=None,new_pincode=None):
            cursor=self.connection.cursor()
            query="UPDATE friend SET name=%s,dob=%s,mobile=%s,email=%s,pincode=%s WHERE name=%s"
            values=(new_name if new_name else name,
                    new_dob if new_dob else self.search_friend(name).dob,
                    new_mobile if new_mobile else self.search_friend(name).mobile,
                    new_email if new_email else self.search_friend(name).email,
                    new_pincode if new_pincode else self.search_friend(name).pincode,
                    name)
            cursor.execute(query,values)
            self.connection.commit()
            print(f"Friend '{name}' has been updated. ")


        #delete function
    def delete_friend(self,name):
            cursor=self.connection.cursor()
            query="DELETE FROM freind WHERE name=%s"
            cursor.execute(query,(name,))
            self.connection.commit()
            print(f"Friend '{name}' has been deleted.")
            

        #search friend function
    def search_friend(self,name) :
            cursor=self.connection.cursor(dictionary=True)
            query="SELECT * FROM friend where name=%s"
            cursor.execute(query,(name))
            result=cursor.fetchone()
            if result:
                return Friend(result['name'],result['dob'],result['mobile'],result['email'],result['pincode'])
            return None
        
        #close connection
    def close_connection(self):
            if self.connection.is_connected():
                self.connection.close()
                print("MySql connection is closed")
                
                
        