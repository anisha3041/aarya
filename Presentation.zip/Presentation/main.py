from friend import Friend
from friend_book import FriendBook

def main():
    friend_book=FriendBook()
    while True:
        print("\nFriend Book Menu:")
        print("1.add Friend")
        print("2.Display All Friend")
        print("3.update Friends")
        print("4.delete Friend")
        print("5.Search Friend")
        print("6.Exit")
        choice=input("Enter your choice (1/2/3/4/5/6):")
        if choice =='1':
            name=input("Enter name: ")
            dob=input("Enter your DOB:")
            mobile=input("Enter mobile:")
            email=input("Enter email:")
            pincode=input("Enter pincode:")
            new_friend=Friend(name,dob,mobile,email,pincode)
            friend_book.add_friend(new_friend)
            print("Friend added Successfully!")
        elif choice =='2':
            print("\nAll Friends:")
            friend_book.display_all_friend()
        elif choice =='3':
            updated_name=input("Enter your update name:")
            updated_dob=input("Enter your update DOB:")
            updated_mobile=input("Enter  your updated mobile:")
            updated_email=input("Enter your updated email:")
            updated_pincode=input("Enter your updated pincode:")
            updated=Friend(updated_name,updated_dob,updated_mobile,updated_email,updated_pincode)
            friend_book.update_friend(updated)
            print("friend updated Successfully!")
        elif choice =='4':
            print("\n Delete Friend")
            friend_book.delete_friend()
        elif choice =='5':
            print("Existing Friend Book. Goodbye!")
            friend_book.close_connection()
            break
        else:
            print("Invalid choice.Please enter a valid option.")
main()


